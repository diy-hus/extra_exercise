#include <io.h>
#include <delay.h>
#include <glcd.h>
#include <font5x7.h>
#include <stdio.h>
#include <stdlib.h>

bool gameOver = false;
bool getInput = false;
int state = 0;
int ball_x = 60;
int ball_y = 30;
int keypad[3][3] = {1,2,3,4,5,6,7,8,9};
int NUM_OF_MOVES = 300;
// 0 & 5: None; 1, 2, 3, 4, 6, 7, 8, 9 theo huong ban phim
int moveSet[10][2] = {{0, 0}, {-1, -1}, {0, -2}, {1, -1}, {-2, 0}, {0, 0}, {2, 0}, {-1, 1}, {0, 2}, {1, 1}};
// possible move when reach bound
int up[3] = {7, 8, 9};
int right[3] = {1, 4, 7};
int down[3] = {1, 2, 3};
int left[3] = {3, 6, 9};
int random = -1;

// "inherited" from tai lieu thuc hanh
char read() {
    char a, i, j;
    for(j = 0; j < 3; j++ ){
        if (j == 0) PORTF = 0b11111101;
        if (j == 1) PORTF = 0b11110111;
        if (j == 2) PORTF = 0b11011111;
        for(i = 0; i < 3; i++){
            if (i == 0){
                a = PINF&0x04;
                if(a != 0x04)
                    return keypad[i][j];
            }
            if (i == 1){
                a = PINF&0x10;
                if (a != 0x10)
                    return keypad[i][j];
            }
            if (i == 2){
                a = PINF&0x01;
                if (a != 0x01)
                    return keypad[i][j];
            }
        }
    }
    return 0;
}


// Timer 0 overflow interrupt service routine with 1 ms
interrupt [TIM0_OVF] void timer0_ovf_isr(void)
{
    TCNT0=0x06;
    // Place your code here
    if (getInput) {
        state = read();
        if (state != 0 && state != 5)
            getInput = false;
    }
        
}

void refresh() {
    gameOver = false;
    ball_x = 60;
    ball_y = 30;
    getInput = false;
}

void createObject() {
     glcd_clear();
     // Four hole
     glcd_circle(2, 2, 2);
     glcd_circle(82, 2, 2);
     glcd_circle(2, 46, 2);
     glcd_circle(82, 46, 2);
     // Ball
     glcd_putpixel(ball_x, ball_y, 255);
}

bool winning_condition() {
    if (ball_x <= 3 && ball_y <= 3)
        return true;
    if (ball_x >= 81 && ball_y <= 3)
        return true;
    if (ball_x <= 3 && ball_y >= 45)
        return true;
    if (ball_x >= 83 && ball_y >= 45)
        return true;
    return false; 
}

void handle_bound() {
    // if dap tuong
    random = rand() % 3;
    if (ball_y <= 1)
        state = up[random];
    if (ball_y >= 47)
        state = down[random];
    if (ball_x <= 1)
        state = left[random];
    if (ball_x >= 83)
        state = right[random];
}

void bi_a() {
    int move;
    glcd_clear();
    delay_ms(100);
    glcd_outtextxy(10, 10, "BI-AAAAA");
    glcd_outtextxy(10, 40, "START: BT1");
    while (PINB.2 != 0) {};
    glcd_clear();
    glcd_outtextxy(35,15, "GO!");
    delay_ms(500);
    createObject();
    
    while (!gameOver) {
        getInput = true;
        while (!getInput) {};
        for (move = 1; move <= NUM_OF_MOVES; move++) {
            if (winning_condition()) {
                gameOver = true;
                break;
            }
            handle_bound();
            glcd_putpixel(ball_x, ball_y, 0);
            ball_x = ball_x + moveSet[state][0];
            ball_y = ball_y + moveSet[state][1];
            glcd_putpixel(ball_x, ball_y, 255);
            delay_ms(20 + move / 10);
        }
              
    }
    
    glcd_clear();
    glcd_outtextxy(12,10, "YOU WIN!");
    glcd_outtextxy(10,30, "RETURN: BT1");
    delay_ms(1000);
}

void main(void)
{
    //init GLCD
    GLCDINIT_t glcd_init_data;
    glcd_init_data.font=font5x7;
    //bias and vlcd must set high to clearly see the ball movement
    glcd_init_data.temp_coef=140;
    glcd_init_data.bias=4;
    glcd_init_data.vlcd=63;
    glcd_init(&glcd_init_data);
    
    //init Timer/Counter 0 with time period = 1 ms
    ASSR=0<<AS0;
    TCCR0=(0<<WGM00) | (0<<COM01) | (0<<COM00) | (0<<WGM01) | (0<<CS02) | (1<<CS01) | (1<<CS00);
    TCNT0=0x06;
    OCR0=0x00;
    TIMSK=(0<<OCIE2) | (0<<TOIE2) | (0<<TICIE1) | (0<<OCIE1A) | (0<<OCIE1B) | (0<<TOIE1) | (0<<OCIE0) | (1<<TOIE0);
    ETIMSK=(0<<TICIE3) | (0<<OCIE3A) | (0<<OCIE3B) | (0<<TOIE3) | (0<<OCIE3C) | (0<<OCIE1C);      
    
    //setup port
    DDRF = 0b11101010;
    //BT on
    DDRB = 0x00;
    PORTB = 0x05;
    delay_ms(150);
    #asm("sei")
    bi_a(); 
 
while (1)
    {   
        if (PINB.2 == 0) {
            refresh();
            bi_a(); 
        }
    }
}
