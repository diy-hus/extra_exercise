#include <io.h>
#include <delay.h>
#include <glcd.h>
#include <font5x7.h>
#include <stdio.h>
#include <stdlib.h>
#include <ehe.c>

bool gameOver = false;
char i;
char x = 10;
char y = 24;
char xObject[] = {84, 84, 84, 84};
char yObject[] = {48, 48, 48, 48};
char height[] = {12, 14, 20, 18};
char inverse[] = {0, 0, 0, 0};
char speed = 3;
int score = 0;
char counter = 0;
bool isStarted = false;

unsigned char outputScore[10];
bool run[] = {true, false, false, false};

// Timer 0 overflow interrupt service routine
interrupt [TIM0_OVF] void timer0_ovf_isr(void)
{
    TCNT0=0x06;
    // Place your code here
    if (!gameOver && isStarted) {
        if (PINB.2 == 0 && counter == 0) {
                y -= 9;
                counter = 1;
        }
        
        if (counter > 0)
            counter++;
        if (counter == 255)
            counter = 0;
    }
}

void refresh() {
    PORTC = 0x00;
    x = 10;
    y = 24;
    counter = 0;
    score = 0;
    for (i = 0; i < 4; i++) {
        xObject[i] = 84;
        yObject[i] = 48;
        inverse[i] = 0;
        run[i] = false;
    }
    run[0] = true;
    height[0] = 10;
    height[1] = 15;
    height[2] = 20;
    height[3] = 17;
    gameOver = false;
}

bool touched() {
    for (i = 0; i < 4; i++) {
        //touch is having the same coordinate with the lower and upper object
        if (inverse[i] == 0)
            if (xObject[i] - 4 <= x && x <= xObject[i] && (yObject[i] - height[i] <= y + 2 && y - 2 <= yObject[i]
                                                        || 0 <= y && y + 2 <= height[i] / 2))
                return true;
        else
             if (xObject[i] - 4 <= x && x <= xObject[i] && (yObject[i] - height[i] / 2 <= y + 2 && y - 2 <= yObject[i]
                                                        || 0 <= y && y + 2 <= height[i]))
                return true;                                                  
    }
    return false;
}

void createObject() {
    // Spawn object in order and check for reappear condition
    for (i = 0; i < 4; i++) {
        // Sequentially make object 1 -> 4 run
        if (xObject[i] - 4 <= 60 && i != 3)
            run[i+1] = true; 
        // if an object is about to disappear, restart it's point then icnrease the score by 1 and randomly reverse
        if (xObject[i] <= 6) {
            inverse[i] = rand() % 2;
            xObject[i] = 84;
            score++;
            //turn on role for fun
            if (score % 4 == 1) {
                PORTC.0 = 0;
                PORTC.3 = 1;
            }
            else if (score % 4 == 2) {
                PORTC.3 = 0;
                PORTC.2 = 1;
            }
            else if (score % 4 == 3) {
                PORTC.2 = 0;
                PORTC.1 = 1;
            }
            else {
                PORTC.1 = 0;
                PORTC.0 = 1;
            }
        }
    }
        
    // Run object from right to left
    for (i = 0; i < 4; i++) {
        if (run[i]) {
            if (inverse[i] == 0) {
                glcd_rectangle(xObject[i], yObject[i], xObject[i] - 4, yObject[i] - height[i]);
                glcd_rectangle(xObject[i], 0, xObject[i] - 4, height[i] / 2);
            }
            else {
                glcd_rectangle(xObject[i], yObject[i], xObject[i] - 4, yObject[i] - height[i] / 2);
                glcd_rectangle(xObject[i], 0, xObject[i] - 4, height[i]);
            }
            
            xObject[i] -= speed;
        }
    }
}

void flappyBoy() {
    glcd_clear();
    delay_ms(100);
    glcd_outtextxy(10, 10, "FLAPPY BIRD");
    glcd_putimagef(39, 25,new_font,0);
    glcd_outtextxy(10, 40, "START: BT1");
    while (PINB.2 != 0) {};
    glcd_clear();
    glcd_outtextxy(35,15, "GO!");
    delay_ms(500);
    
    isStarted = true;
    while (!gameOver) {
        glcd_clear();
        createObject();
        glcd_putimagef(x,y,new_font,0);
        y+=4;
    //    if (PINB.2 == 0)
   //         y -= 8;
        if (y >= 46 || y <= 2 || touched()) {
            gameOver = true;
            isStarted = false;
        }
        delay_ms(250);
    }
    
    sprintf(outputScore, "%d", score);
    glcd_clear();
    glcd_outtextxy(12,10, "GAME OVER!");
    glcd_outtextxy(15,20, "SCORE: ");
    glcd_outtextxy(55,20, outputScore);
    glcd_outtextxy(10,30, "RETURN: BT1");
    delay_ms(1000);
}

void main(void)
{
    //init GLCD
    GLCDINIT_t glcd_init_data;
    glcd_init_data.font=font5x7;
    glcd_init_data.temp_coef=140;
    glcd_init_data.bias=4;
    glcd_init_data.vlcd=60;
    glcd_init(&glcd_init_data);
    
    //init Timer/Counter 0 with time period = 1 ms
    ASSR=0<<AS0;
    TCCR0=(0<<WGM00) | (0<<COM01) | (0<<COM00) | (0<<WGM01) | (0<<CS02) | (1<<CS01) | (1<<CS00);
    TCNT0=0x06;
    OCR0=0x00;
    TIMSK=(0<<OCIE2) | (0<<TOIE2) | (0<<TICIE1) | (0<<OCIE1A) | (0<<OCIE1B) | (0<<TOIE1) | (0<<OCIE0) | (1<<TOIE0);
    ETIMSK=(0<<TICIE3) | (0<<OCIE3A) | (0<<OCIE3B) | (0<<TOIE3) | (0<<OCIE3C) | (0<<OCIE1C);      
    
    //setup port
    //turn on all light
    DDRD = 0xff;
    PORTD = 0xff;
    //role on
    DDRC = 0x0f;
    //BT on
    DDRB = 0x00;
    PORTB = 0x05;
    delay_ms(150);
    #asm("sei")
    flappyBoy();
 
while (1)
    {   
        if (PINB.2 == 0) {
            refresh();
            flappyBoy();   
        }
    }
}
