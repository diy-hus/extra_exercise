/****************************************************************************
Font created by the LCD Vision V1.05 font & image editor/converter
(C) Copyright 2011-2013 Pavel Haiduc, HP InfoTech s.r.l.
http://www.hpinfotech.com

Font name: flappybird
Fixed font width: 6 pixels
Font height: 6 pixels
First character: 0x20
Last character: 0x7F

Exported font data size:
580 bytes for displays organized as horizontal rows of bytes
580 bytes for displays organized as rows of vertical bytes.
****************************************************************************/

#ifndef _EHE_INCLUDED_
#define _EHE_INCLUDED_

extern flash unsigned char flappybird[];

#endif

